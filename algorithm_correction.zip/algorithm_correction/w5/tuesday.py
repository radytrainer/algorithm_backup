
playerOne = str(input("Player One: "))
playerTwo = str(input("Player Two: "))

isPlayerOneWin = (playerOne == "R" and playerTwo == "S") or (playerOne == "P" and playerTwo == "R") or (playerOne == "S" and playerTwo == "P")
isPlayerTwoWin = (playerOne == "R" and playerTwo == "P") or (playerOne == "P" and playerTwo == "S") or (playerOne == "S" and playerTwo == "R")
isEqual = (playerOne == playerTwo) and (playerOne == "R" or playerOne == "P" or playerOne == "S")

if isPlayerOneWin:
    print("Player 1 Won")
elif isPlayerTwoWin:
    print("Player 2 Won")
elif isEqual:
    print("Equality")   
else:
    print("Sign is not correct")

