number = int(input("Number: "))
sum = 0
for n in range(1, number + 1):
    sum = sum + n * n
print(sum)
