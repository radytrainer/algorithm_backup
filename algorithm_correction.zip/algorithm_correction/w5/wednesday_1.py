postion = str(input("Princess Position: "))
balook = str(input("Balook move: "))

has3Chars = len(postion) == 3
if not has3Chars:
    print("Wrong position format!")
else:
    firstCharsIsNumber = postion[0].isnumeric()
    secondCharsIsSemi = postion[1] == ";"
    thirdCharsIsNumber = postion[2].isnumeric()
    if not (firstCharsIsNumber and secondCharsIsSemi and thirdCharsIsNumber):
        print("Wrong position format!")
    else:
        x = int(postion[0])
        y = int(postion[2])
        if x > 3 or x < 0 or y > 3 or y < 0:
            print("Wrong postion format!")
        else:
            result = ""
            bx = 0
            by = 0
            for n in range(len(balook)):
                step = balook[n]
                if step == "R" or step == "r":
                    bx = bx + 1
                elif step == "L" or step == "l":
                    bx = bx - 1 
                elif step == "D" or step == "d":
                    by = by + 1
                elif step == "U" or step == "u":
                    by = by - 1
            if bx > 3 or bx < 0 or by > 3 or by < 0:
                result = "Balook out of grid!"
            else:
                for row in range(4):
                    for col in range(4):
                        if (col == x and col == bx) and (row == y and row == by):
                            result = result + "* "
                        elif col == bx and row == by:
                            result = result + "B "
                        elif col ==  x and row == y:
                            result = result + "P "
                        else:
                            result = result + "0 "
                    result = result + "\n"
            print(result)