
min = 0
max = 0

for index in range(4):
    number = int(input("Number " + str(index + 1) + " = ")) 

    if index == 0:
        min = number 
        max = number 
    else:
        if number > max: 
            max = number 

        if number < min:
            min = number
print("The minimum number is: " + str(min))
print("The maximum number is: " + str(max))