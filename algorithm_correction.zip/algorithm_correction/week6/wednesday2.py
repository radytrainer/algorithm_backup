numberOfValues = int(input("Number of value:"))
sumOdd = 0
sumEven = 0
contain22 = False

for i in range(numberOfValues):
    value = int(input())

    if value % 2 == 1:
        sumOdd = sumOdd + value
    else:
        sumEven = sumEven + value

    if value == 22:
        contain22 = True 
if contain22:
    print("Result is: " + str(sumEven))
else:
    print("Result is: " + str(sumOdd))