numberOfLevels = int(input("Number of Levels: "))
numberOfStars = 1
star = ""
space = numberOfLevels - 1

for i in range(numberOfLevels):

    for k in range(space):
        star = star + " "

    for n in range(numberOfStars):
        star = star + "*"
    
    numberOfStars = numberOfStars + 2
    space = space - 1
    
    star = star + "\n"
print(star)