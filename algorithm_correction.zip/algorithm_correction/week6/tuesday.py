
numberOfLoop = 0
numberOf10 = 0
sumPreEqual10 = False
preNumber = 0
hasPreNumber = False

while numberOfLoop < 6 and not (numberOf10 == 3 or sumPreEqual10):
    value = int(input("Number: "))

    numberOfLoop = numberOfLoop + 1

    if value == 10:
        numberOf10 = numberOf10 + 1

    if preNumber + value == 10 and hasPreNumber:
        sumPreEqual10 = True 

    preNumber = value
    hasPreNumber = True
    
if numberOf10 == 3 or sumPreEqual10:
    print("WIN")
else:
    print("LOST")