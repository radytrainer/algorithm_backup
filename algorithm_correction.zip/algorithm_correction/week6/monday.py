#step 1: get number position
positionNumber = str(input("Enter the 2 number: "))

#step 2: check string length
has5Chars = len(positionNumber) == 5

if not has5Chars:
    print("Wrong position format")
else:
    #step 3: check number ; number
    char0IsNum = positionNumber[0].isnumeric()
    char1IsNum = positionNumber[1].isnumeric()
    char3IsSemi = positionNumber[2] == ";"
    char4IsNum = positionNumber[3].isnumeric()
    char5IsNum = positionNumber[4].isnumeric()

    if not (char0IsNum and char1IsNum and char3IsSemi and char4IsNum and char5IsNum):
        print('Wrong position format')
    else:
        #step 4: convert to integer number
        numberBeforeSemi = int(positionNumber[0:2])
        numberAfterSemi = int(positionNumber[3:5])
        # step 5: sum number
        print(numberBeforeSemi + numberAfterSemi)
