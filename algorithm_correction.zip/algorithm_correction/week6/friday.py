x_princess1 = 3
y_princess1 = 0

x_princess2 = 1
y_princess2 = 3

action = str(input("Actions: "))
x = 0
y = 0

savePrincess1 = False 
savePrincess2 = False

for i in range(len(action)): 
    step = action[i]
    if step == "R" or step == "r":
        x = x + 1
    elif step == "L" or step == "l":
        x = x - 1
    elif step == "D" or step == "d":
        y = y + 1
    elif step == "U" or step == "u":
        y = y - 1
    elif step == "*":
        if x == x_princess1 and y == y_princess1:
            savePrincess1 = True 

        if x == x_princess2 and y == y_princess2:
            savePrincess2 = True 
if savePrincess1 and savePrincess2:
    print("WIN")
else:
    print("LOOSE")