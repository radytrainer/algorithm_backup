numberOne = int(input("Enter number one: "))
numberTwo = int(input("Enter number two: "))
numberThree = int(input("Enter number three: "))

if numberTwo == numberOne + 1 and numberThree == numberTwo + 1:
    print("SEQUENCE")
else:
    print("NOT SEQUENCE")

# n2 = n1 + 1
# n3 = n2 + 1

