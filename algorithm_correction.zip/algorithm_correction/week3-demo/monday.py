
numberOfValue = int(input("Enter number of value: "))
countOf10 = 0
for i in range(numberOfValue):
    value = int(input("Value " + str(i + 1) + ": "))
    while value <= 0:
        print("Value must be greater than 0!")
        value = int(input("Value " + str(i + 1) + ": "))

    if value == 10:
        countOf10 = countOf10 + 1
print("The number of 10 is:" + str(countOf10))