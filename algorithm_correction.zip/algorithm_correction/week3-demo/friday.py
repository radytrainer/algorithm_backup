action = str(input("Action: "))
positionX = 0
positionY = 0
for i in range(len(action)):
    act = action[i]
    if act == "L" or act == "l":
        positionX = positionX - 1
    elif act == "R" or act == "r":
        positionX = positionX + 1
    elif act == "U" or act == "u":
        positionY = positionY + 1
    elif act == "D" or act == "d":
        positionY = positionY - 1
    else:
        print("Wrong action")

isPrincessPosition = positionX == 2 and positionY == 1
if isPrincessPosition:
    print("WIN")
else:
    print("LOOSE")
    