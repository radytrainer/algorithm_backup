
numberOfValue = int(input("Ente number of value:"))
while numberOfValue < 4:
    print("We need minimum 4 values")
    numberOfValue = int(input("Ente number of value:"))

n1 = 0
n2 = 0
indexN1 = 0
indexN2 = 0
indexN3 = 0
isFound = False
for i in range(numberOfValue):
    n3 = int(input()) 

    if i > 1 and n3 == n2 and n2 == n1: 
        if not isFound:
            isFound = True
            indexN1 = i - 2 
            indexN2 = i - 1
            indexN3 = i
    if i > 0:
        n1 = n2 
    n2 = n3 
if isFound:
    print("Found at: " + str(indexN1) + ", " + str(indexN2) + ", " + str(indexN3))
else:
    print("Not found!")