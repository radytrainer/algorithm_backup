
word = str(input("Your Word: ")) 
isValidOrder = True
for i in range(len(word)):
    character = word[i] 
    isACorrect = (character != "a"  and i % 2 == 0)  
    if isACorrect:
        isValidOrder = False
    isBCorrect = (character != "b"  and i % 2 == 1) 
    if isBCorrect:
        isValidOrder = False

isValidSize = len(word) % 2 == 0

if isValidOrder and isValidSize:
    print("GOOD")
else:
    print("BAD")
    