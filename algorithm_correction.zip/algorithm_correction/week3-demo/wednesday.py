numberOfValue = int(input("Enter number of value: "))

chainSize = 0
chainValue = 0
maxSize = 0
for i in range(numberOfValue):
    value = int(input()) # 1 1 1 4 4
    if i == 0:
        chainValue = value # chainValue = 1
        chainSize = 1
    else:
        if value == chainValue: # 4 == 4
            chainSize = chainSize + 1 #chainSize = 2
        else:
            chainValue = value # chainValue = 4
            chainSize = 1

    if chainSize > maxSize: # 2 > 3
        maxSize = chainSize # maxSize = 3

print("Result is: " + str(maxSize))