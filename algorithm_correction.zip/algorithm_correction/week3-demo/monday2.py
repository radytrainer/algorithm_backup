numberOfValue = int(input("Enter number of value: "))
n1 = 0
n2 = 0
isGoodList = False
if numberOfValue > 3:
    for i in range(numberOfValue):
        n3 = int(input()) # 3 6 9
        if i > 1 and n3 == n2 + n1: 
            isGoodList = True
        if i > 0:
            n1 = n2 # n1 = 3
        n2 = n3 # n2 = 6
    if isGoodList:
        print("GOOD LIST")
    else:
        print("BAD LIST")
else:
    print("BAD LIST")