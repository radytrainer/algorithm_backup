actions = str(input("Action: "))
x = 0
y = 0
actLen = len(actions)
for index in range(actLen):
    act = actions[index]
    if act == "R" or act == "r":
        x = x + 1
    elif act == "L" or act == "l":
        x = x - 1
    elif act == "U" or act == "u":
        y = y + 1
    elif act == "D" or act == "d":
        y = y - 1
if x == 4 and y == 2:
    print("Good 🚀 ")
else:
    print("Bad 🐓  ")


    