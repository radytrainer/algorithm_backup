numberOfValue = int(input("Enter number of value: "))
count10 = 0


for index in range(numberOfValue):
    number = int(input("Value " + str(index + 1) + ": "))
    while number <= 0:
        print("Value shall be greater than 0!")
        number = int(input("Value " + str(index + 1) + ": "))
    if number == 10:
        count10 = count10 + 1

#welcome
    
print("The number of 10 is: " + str(count10))