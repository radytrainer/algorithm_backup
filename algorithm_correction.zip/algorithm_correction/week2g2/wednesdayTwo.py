numberOfValue = int(input("Enter number of value:"))
n1 = 0
n2 = 0
sequenceNumber = 0
if numberOfValue >= 3:
    for index in range(numberOfValue):
        n3 = int(input()) 
        if index >= 2:
            if n2 == n1 + 1 and n3 == n2 + 1:
                sequenceNumber = sequenceNumber + 1
        #update n2
        if index >= 1:
            n1 = n2 
        #update n1
        n2 = n3 
    print("Result is: ", sequenceNumber)
else:
    print("This number must be equal to 3 or greater")