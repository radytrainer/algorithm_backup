numberOfValue = int(input("Enter number of value:"))
indexOf7 = 0
isFound7 = False
for index in range(numberOfValue):
    number = int(input())
    if number == 7 and not isFound7: #not false = true // not true = false
        indexOf7 = index
        isFound7 = True
if isFound7 == True:
    print("Number of 7 index is: ", indexOf7)
else:
    print("No 7 entered")