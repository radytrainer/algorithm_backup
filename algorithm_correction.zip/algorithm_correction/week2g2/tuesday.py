numberOfValue = int(input("Enter number of value:"))
preNumber = 0
bigNumber = 0
for index in range(numberOfValue):
    currentNumber = int(input())
    if index > 0 and preNumber < currentNumber:
       bigNumber = bigNumber + 1
    preNumber = currentNumber
print("The result is: ", bigNumber)

