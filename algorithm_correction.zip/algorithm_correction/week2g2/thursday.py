left = 0
right = 0
isMove = True
position = 0
while isMove:
    action = str(input("Action: "))
    if action == "l" or action == "L":
        left = left - 1
    if action == "r" or action == "R":
        right = right + 1
    if action == 's' or action  == 'S':
        isMove = False
position = left + right
print("The position of Balook is: ", position)