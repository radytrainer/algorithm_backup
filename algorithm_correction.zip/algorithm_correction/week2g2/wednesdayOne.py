n1 = int(input("Enter number one: "))
n2 = int(input("Enter number two: "))
n3 = int(input("Enter number three: "))

if n2 == n1 + 1 and n3 == n2 + 1:
    print("SEQUENCE")
else:
    print("NOT SEQUENCE")