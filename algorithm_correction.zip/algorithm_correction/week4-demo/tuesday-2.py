number = int(input("You value: ")) # 5

while not (number >= 1 and number <= 6): # 5 >= 1 and 5 <= 6 => True : not True = False
    number = int(input("Incorrect . Try again: "))
print("Thank ! You value " + str(number) + " is valid.")

