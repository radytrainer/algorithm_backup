numberOne = int(input("Enter number one: "))
numberTwo = int(input("Enter number two: "))
isValid = (numberOne == 4 and numberTwo == 1) or (numberOne == 1 and numberTwo == 4)
if isValid:
    print("WIN")
else:
    print("LOST")