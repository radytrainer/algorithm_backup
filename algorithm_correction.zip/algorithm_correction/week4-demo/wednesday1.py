numberOfValue = int(input("Enter number of value:")) # 4
sum = 0
for i in range(numberOfValue):
    number = int(input()) #  3 4 5 5
    if i >= numberOfValue - 3:  #   numberOfValue - 3 => i
        sum = sum + number 

print("Result is: " + str(sum))


