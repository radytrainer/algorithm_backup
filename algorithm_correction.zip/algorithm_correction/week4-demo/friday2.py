
action = str(input("Actions: "))
x = 0
y = 0
isBalookDead = False
for i in range(len(action)):
    #Action 
    act = action[i]
    if act == "r" or act == "R":
        x = x + 1
    elif act == "l" or act == "L":
        x = x - 1
    elif act == "u" or act == "U":
        y = y + 1
    elif act == "d" or act == "D":
        y = y - 1
    else:
        print("Wrong action!")

    # check if balook dead (0, 1), (2, 1), (4, 0)
    isTrap = (x == 0 and y == 1) or (x == 2 and y == 1) or (x == 4 and y == 0)
    if isTrap :
        isBalookDead = True

isSave = x == 4 and y == 2
if isSave and not isBalookDead:
    print("WIN")
else:
    print("LOOSE")