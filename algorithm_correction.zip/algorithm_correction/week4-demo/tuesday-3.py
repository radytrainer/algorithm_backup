numberOfValue = int(input("Enter number of value: ")) 
sum = 0
isSevenFound = False
for index in range(numberOfValue):
    value = int(input()) 

    if value == 7:
        isSevenFound = True
        
    if not isSevenFound:
        sum = sum + value 
print("Result is: " + str(sum))

