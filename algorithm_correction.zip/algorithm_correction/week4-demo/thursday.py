

word = str(input("Your word: "))
result = ""
for i in range(len(word)):
    letter = word[i]
    if letter == "a" or letter == "A":
        star = "*"
    else:
        star = letter
    result = result + star 
print(result)

