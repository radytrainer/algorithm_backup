
word  = str(input("Your word: ")) 
indexOfSemiColumn = -1 # Not found
for i in range(len(word)):
    letter = word[i]
    if letter == ";":
        indexOfSemiColumn = i
    
if indexOfSemiColumn == -1:
        print("No semi column found")
else:
    wordOne = word[0:indexOfSemiColumn] # aaa;bbb
    wordTwo = word[indexOfSemiColumn + 1: len(word)] 
    print(wordOne)
    print(wordTwo)

    