positionX = int(input("Princess X: "))
positionY = int(input("Princess Y: "))
action = str(input("Actions: "))
x = 0
y = 0
for i in range(len(action)):
    act = action[i]
    if act == "r" or act == "R":
        x = x + 1
    elif act == "l" or act == "L":
        x = x - 1
    elif act == "u" or act == "U":
        y = y + 1
    elif act == "d" or act == "D":
        y = y - 1
    else:
        print("Wrong action!")
isSave = x == positionX and y == positionY
if isSave:
    print("WIN")
else:
    print("LOOSE")