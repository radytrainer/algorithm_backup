# Step 1: Get princess position as a string
position = str(input("Princess position: "))  

# Step 2: check if string length > 3 character
has3Character = len(position) == 3
if not has3Character:
    print("Wrong position format!")
else:
    # Step 3: check if character is number between index 0 and 2
    firstCharIsNumber = position[0].isnumeric()
    secondCharIsSemi = position[1] == ";"
    thirdCharIsNumber = position[2].isnumeric()

    if not (firstCharIsNumber and secondCharIsSemi and thirdCharIsNumber):
        print("Wrong position format!")
    else:
        # Step 4: convert postion to integer 
        x = int(position[0])
        y = int(position[2])
        # Step 5:  check if position in range [0, 3]
        if x > 3 or x < 0 or y > 3 or y < 0:
            print("Wrong position format!")
        else:
            # Step 6: Display grid
            result = ""
            for row in range(4): # Row 0 1 2 3
                for col in range(4): # Column 0 1 2 3
                    if col == x and row == y: 
                        result = result + "P "
                    else:
                        result = result + "0 "                                    
                result = result + "\n"
            print(result)