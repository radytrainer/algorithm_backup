# Step : Enter maximum number 
max = int(input("Max number: "))

#Step : Compute the sum of square
sum = 0
for number in range(1, max + 1):  
    sum = sum + number * number
print("Sum of the squares is:" + str(sum))