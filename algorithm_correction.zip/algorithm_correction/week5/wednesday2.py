# Step 1: Get princess position as a string and balook move
position = str(input("Princess position: "))  
balook = str(input("Balook move: "))

# Step 2: check if string length > 3 character
has3Character = len(position) == 3
if not has3Character:
    print("Wrong position format!")
else:
    # Step 3: check if character is number between index 0 and 2
    firstCharIsNumber = position[0].isnumeric()
    secondCharIsSemi = position[1] == ";"
    thirdCharIsNumber = position[2].isnumeric()

    if not (firstCharIsNumber and secondCharIsSemi and thirdCharIsNumber):
        print("Wrong position format!")
    else:
        # Step 4: convert postion to integer 
        x = int(position[0])
        y = int(position[2])
        # Step 5:  check if position in range [0, 3]
        if x > 3 or x < 0 or y > 3 or y < 0:
            print("Wrong position format!")
        else:
            # Step 6: Balook position
            result = ""
            bx = 0
            by = 0
            for i in range(len(balook)):
                step = balook[i]
                if step == "R" or step == "r":
                    bx = bx + 1
                elif step == "L" or step == "l":
                    bx = bx - 1
                elif step == "U" or step == "u":
                    by = by - 1
                elif step == "D" or step == "d":
                    by = by + 1

                if bx > 3 or bx < 0 or by > 3 or by < 0:
                    result = "Balook is out of grid!"
                else:

                    #build grid

                    for row in range(4): # Row 0 1 2 3
                        for col in range(4): # Column 0 1 2 3
                            if (col == x and col == bx) and (row == y and row == by):
                                result = result + "* "
                            elif col == bx and row == by:
                                result = result + "B "
                            elif col == x and row == y: 
                                result = result + "P "
                            else:
                                result = result + "0 "                                    
                        result = result + "\n"
                print(result)