result = ""
for row in range(4): # Row 0 1 2 3
    for col in range(4): # Column 0 1 2 3
        result = result + "0 "                                    
    result = result + "\n"
print(result)