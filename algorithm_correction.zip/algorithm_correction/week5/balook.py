balook = str(input("Balook move: "))
bx = 0
by = 0
for i in range(len(balook)):
    step = balook[i]
    if step == "R" or step == "r":
        bx = bx + 1
    elif step == "L" or step == "l":
        bx = bx - 1
    elif step == "U" or step == "u":
        by = by - 1
    elif step == "D" or step == "d":
        by = by + 1
    