# Step 1: Enter the players sign
playerOne = str(input("Player One sign: "))
playerTwo = str(input("Player Two sign: "))

# Step 2: check if player one win
isPlayerOneWin = (playerOne == "R" and playerTwo == "S") or (playerOne == "S" and playerTwo == "P") or (playerOne == "P" and playerTwo == "R")
# Step 3: check if player two win
isPlayerTwoWin = (playerOne == "R" and playerTwo == "P") or (playerOne == "S" and playerTwo == "R") or (playerOne == "P" and playerTwo == "S")
# Step 4: check if player are equal
isPlayersEqual = (playerOne == playerTwo) and (playerOne == "R" or playerOne == "S" or playerOne == "P")

if isPlayerOneWin:
    print("Player 1 Won")
elif isPlayerTwoWin:
    print("Player 2 Won")
elif isPlayersEqual:
    print("Equality")
else: # Step 5: ERROR ! NOT CORRECT SIGN
    print("Sign is not correct!")

