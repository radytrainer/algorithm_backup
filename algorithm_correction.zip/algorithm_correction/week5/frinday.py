# Step 1: Get value from input
number = int(input("Number: ")) 

# Step 2: Check if number > 0
result = ""
result = result + str(number) + "," 
if number < 0: 
    result = "Number shall be positive!"
else:
    while number != 1: 
        if number % 2 == 1: 
            number = number * 3 + 1 
        else:
            number = number / 2 
        result = result + str(int(number)) + "," 
print(result[:-1]) 
